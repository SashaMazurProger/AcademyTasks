﻿using CoffeeApp.Domain.Entities.Common;
using System;
using CoffeeApp.Domain.Core.ClientSide;

namespace Test
{
    class Program
    {
        static void Main(string[] args)
        {
            MainStartConfig.Main();
        }
    }
}
