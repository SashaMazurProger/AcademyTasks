﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserManagerWeb.Models.Abstract
{
    public interface IProductsRepository
    {
        List<Products> FilterProducts(int categoryId, List<ProductFilterViewModel> filters = null);
    }
}
