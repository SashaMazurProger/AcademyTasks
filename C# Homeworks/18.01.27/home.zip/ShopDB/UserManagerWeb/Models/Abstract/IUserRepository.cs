﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserManagerWeb.Models
{
    public interface IUserRepository
    {
        List<UserProfiles> Users();
        UserProfiles GetUserById(int? id);
        void CreateUser(UserProfiles u);
        void UpdateUser(UserProfiles u);
        void DeleteUser(int id);
        List<UserProfiles> FindUsers(string name = null, string tel = null);
    }
}
