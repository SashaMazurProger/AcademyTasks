﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace UserManagerWeb.Models
{
    public class DBUserRepo:IUserRepository
    {
        private ShopDBContext db;
        public DBUserRepo(ShopDBContext db)
        {
            this.db = db;
        }
        
        public void CreateUser(UserProfiles u)
        {
            db.UserProfiles.Add(u);
            db.SaveChanges();
        }

        public void UpdateUser(UserProfiles u)
        {
            UserProfiles found = db.UserProfiles.Where(i => i.Id == u.Id).FirstOrDefault();
            if (found != null)
            {
                db.Entry(found).State = EntityState.Modified;
            }
        }

        public void DeleteUser(int id)
        {
            UserProfiles found = db.UserProfiles.Where(i => i.Id == id).FirstOrDefault();
            if (found != null)
            {
                db.UserProfiles.Remove(found);
                db.SaveChanges();
            }
        }

        public List<UserProfiles> FindUsers(string name = null, string tel = null)
        {
            List<UserProfiles> users = (from u in db.UserProfiles

                                where u.Name.ToUpper().Contains(name.ToUpper()) ||
                                u.Telephone.ToUpper().Contains(tel.ToUpper())

                                select u).ToList();

            return users;

        }

        public List<UserProfiles> Users()
        {
            return db.UserProfiles.ToList();
        }


        public UserProfiles GetUserById(int? id)
        {
            return db.UserProfiles.Find(id);
        }
        public List<ProductCategories> GetCats()
        {
            return db.ProductCategories.ToList();
        }
    }
}