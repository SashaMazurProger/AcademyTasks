﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UserManagerWeb.Models.ViewModels
{
    public class ProductListViewModel
    {
        public List<Products> Products { get; set; }

        public int CategoryId { get; set; }

        public List<ProductFilterViewModel> Filters { get; set; }
    }
}