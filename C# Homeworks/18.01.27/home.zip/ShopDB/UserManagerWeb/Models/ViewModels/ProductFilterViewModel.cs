﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UserManagerWeb.Models
{
    public class ProductFilterViewModel
    {
        public string Name { get; set; }
        public List<ProductFilterValue> FilterValues { get; set; }

        public ProductFilterViewModel()
        {
            FilterValues = new List<ProductFilterValue>();
        }
    }
}