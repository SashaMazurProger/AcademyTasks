﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UserManagerWeb.Models
{
    public class DbProcedureFilter
    {
        public string FilterName { get; set; }
        public string FilterValue { get; set; }
        public int CountProducts { get; set; }
    }
}