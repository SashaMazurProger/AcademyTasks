﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace UserManagerWeb.Models
{
    public class DBFilterRepo:IFilterRepository
    {
        private ShopDBContext db;

        public DBFilterRepo(ShopDBContext db)
        {
            this.db = db;
        }
        public List<ProductFilterViewModel> GetProductFiltersByCategoryId(int prodCategoryId)
        {
            List<ProductFilterViewModel> filters = new List<ProductFilterViewModel>();

            SqlParameter categIdParam=new SqlParameter("@prodCatId",prodCategoryId);

            var dbFilters=db.Database
                              .SqlQuery<DbProcedureFilter>("SelectCategoryFilters @prodCatId",categIdParam) 
                              .ToList();

            for (int i = 0; i < dbFilters.Count; i++)
            {
                DbProcedureFilter curDbFilter = dbFilters[i];

                //шукаємо в нашому списку фільтр з назвою фільтру curDbFilter.FilterName
                ProductFilterViewModel curFilter=filters
                    .Where(f => f.Name == curDbFilter.FilterName)
                    .FirstOrDefault();

                //якщо в списку фільтрів немає такого фільтру додаємо новий в наш список на базі фільтру з запросу до бд
                if (curFilter == null)
                {
                    curFilter = new ProductFilterViewModel();

                    curFilter.Name = curDbFilter.FilterName;

                    curFilter.FilterValues.Add(new ProductFilterValue
                    {
                        Name = curDbFilter.FilterValue,
                        ProductCount = curDbFilter.CountProducts
                    });
                    
                    filters.Add(curFilter);
                }
                else    //або додаємо значення до знайденого фільтру
                {
                    curFilter.FilterValues.Add(new ProductFilterValue
                    {
                        Name = curDbFilter.FilterValue,
                        ProductCount = curDbFilter.CountProducts
                    });
                }

                
            }
            return filters;
        }
    }
}