﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using UserManagerWeb.Models.Abstract;

namespace UserManagerWeb.Models
{
    public class DBProductsRepo:IProductsRepository
    {
        private ShopDBContext db=new ShopDBContext();
        public DBProductsRepo()
        {

        }
        public List<Products> FilterProducts(int categoryId, List<ProductFilterViewModel> filters = null)
        {

            List<Products> products = (from p in db.Products
                                      where p.ProductCategoryId == categoryId
                                      select p).ToList();

            if (filters != null&&filters.Any())
            {
                for (int i = 0; i < filters.Count; i++)
                {
                    ProductFilterViewModel curFilter=filters[i];

                    List<ProductFilterValue> values=curFilter.FilterValues;

                    if (values != null && values.Any())
                    {
                        String curFilName = curFilter.Name;

                        //Вибираємо тільки ті продукти у яких значення фільтру є серед значень поточного(curFilterName) фільтра 
                        products=products.Where(p=>
                            {
                                var fils = p.Filters.Where(f => f.FilterNames.Name == curFilName);

                                foreach (var v in values)
                                {
                                    foreach (var f in fils)
                                    {
                                        if (f.FilterValues.Name == v.Name)
                                        {
                                            return true;
                                        }
                                    }
                                }
                                return false;
                            })
                               .ToList();
                    }
                    
                    
                }

            }
            return products;
        }
    }
}