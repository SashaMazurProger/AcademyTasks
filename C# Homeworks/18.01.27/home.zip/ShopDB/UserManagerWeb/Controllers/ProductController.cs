﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using UserManagerWeb;
using UserManagerWeb.Models;
using UserManagerWeb.Models.Abstract;
using UserManagerWeb.Models.ViewModels;

namespace UserManagerWeb.Controllers
{
    public class ProductController : Controller
    {
        private ShopDBContext db;

        private IFilterRepository filtersRepo;

        private IProductsRepository prodRepo;

        public ProductController()
        {

            db = new ShopDBContext();

            filtersRepo = new DBFilterRepo(this.db);

            prodRepo = new DBProductsRepo();
        }

        // GET: /Product/
        public ActionResult Index()
        {
            var products = db.Products.Include(p => p.ProductCategories);
            return View(products.ToList());
        }

        public ActionResult ProductsByCategory(int categoryId)
        {
            ProductListViewModel model = new ProductListViewModel();

            model.Filters = filtersRepo.GetProductFiltersByCategoryId(categoryId);

            model.Products = prodRepo.FilterProducts(categoryId);

            model.CategoryId = categoryId;

            return null;
        }
    }
}
