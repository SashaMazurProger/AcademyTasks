﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UserManagerWeb;
using UserManagerWeb.Models;
using UserManagerWeb.Models.ViewModels;

namespace ConsoleApplicationTest
{
    class Program
    {
        static void Main(string[] args)
        {

//Відображення товарів по категорії і фільтрам

            DBProductsRepo pr = new DBProductsRepo();

            int categoryId = 5;  //?????

            //перший фільтр
            ProductFilterViewModel f = new ProductFilterViewModel();
            f.Name = "Color";

            f.FilterValues = new List<ProductFilterValue>
            {
               new ProductFilterValue{Name="Red"}
            };

            //другий фільтр
            ProductFilterViewModel f2=new ProductFilterViewModel 
            {
                Name = "Size",
                FilterValues = new List<ProductFilterValue> 
                {
                    new ProductFilterValue { Name = "L" } 
                } 
            };

            //відфільтровані продукти
            var filteredProds = pr.FilterProducts(categoryId, new List<ProductFilterViewModel> { f });

            foreach (var p in filteredProds)
            {
                Console.WriteLine("\n"+p.Name);
                foreach (var fil in p.Filters)
                {
                    Console.WriteLine("\tFilter:{0}  Value:{1}",fil.FilterNames.Name,fil.FilterValues.Name);
                }
            }

            SaveProdsToDatFile(filteredProds);

//Фільтри по категорії

            //IFilterRepository rep = new DBFilterRepo(new ShopDBContext());

            //var fil=rep.GetProductFiltersByCategoryId(4);

            //foreach (var f in fil)
            //{
            //    Console.Write("\n"+f.Name);
            //    foreach (var v in f.FilterValues)
            //    {
            //        Console.Write("\n   {0}({1})",v.Name,v.ProductCount);
            //    }
            //}

//Дерево категорій

            //List<ProductCategories> categories = new ShopDBContext().ProductCategories.ToList();

            //DisplayCategories(categories, null, 0);

           
        }
        public static void SaveProdsToTextFile(List<Products> prods)
        {
            FileInfo info = new FileInfo(@"C:\products.txt");

            using (StreamWriter w = info.CreateText())
            {
                foreach (var pw in prods)
                {
                    w.WriteLine("\n" + pw.Name);
                }
            }
            using (StreamReader r = info.OpenText())
            {
                Console.WriteLine(r.ReadToEnd());
            }
        }
        public static void SaveProdsToDatFile(List<Products> prods)
        {
            FileInfo info = new FileInfo(@"C:\products.dat");

            using (FileStream fs=info.Open(FileMode.CreateNew))
            {
                string names=String.Empty;

                foreach (var pw in prods)
                {
                    names=names+"\n"+pw.Name;
                }

                byte[] bytes = Encoding.Default.GetBytes(names.ToArray());

                fs.Write(bytes, 0, bytes.Length);

                fs.Position = 0;

                byte[] readBytes=new byte[bytes.Length];

                fs.Read(readBytes, 0, bytes.Length);

                Console.WriteLine(Encoding.Default.GetString(readBytes));
            }
           
        }
        public static void DisplayCategories(List<ProductCategories> categories, ProductCategories curCateg = null, int tabs = 0)
        {
            List<ProductCategories> parents;

            List<ProductCategories> endCategories;

            if (curCateg == null)
            {
                parents = categories.Where(c => c.ParentId == null &&
                    categories.Where(i => i.ParentId == c.Id).Any()).ToList();

                endCategories = categories.Where(c => c.ParentId == null &&
                    categories.Where(i => i.ParentId == c.Id).Count() == 0).ToList();
            }
            else
            {
                GetCategoryChilds(curCateg, categories, out parents, out endCategories);
            }
            foreach (var categ in endCategories)
            {
                for (int i = 0; i < tabs; i++)
                {
                    Console.Write("  ");
                }
                Console.WriteLine(categ.Name);
            }

            if (parents.Any())
            {
                foreach (var item in parents)
                {
                    for (int i = 0; i < tabs; i++)
                    {
                        Console.Write("  ");
                    }
                    Console.WriteLine(item.Name);

                    DisplayCategories(categories, item, tabs + 1);
                }

            }
        }
        public static void GetCategoryChilds(ProductCategories curCateg, List<ProductCategories> categories,
            out List<ProductCategories> parents, out List<ProductCategories> endCategories)
        {
            parents = categories.Where(c => c.ParentId == curCateg.Id &&
                categories.Where(i => i.ParentId == c.Id).Any()).ToList();

            endCategories = categories.Where(c => c.ParentId == curCateg.Id &&
                categories.Where(i => i.ParentId == c.Id).Count() == 0).ToList();
        }
    }
}
