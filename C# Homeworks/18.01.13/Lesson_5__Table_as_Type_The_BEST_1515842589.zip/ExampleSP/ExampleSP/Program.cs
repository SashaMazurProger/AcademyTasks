﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExampleSP
{
    public class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Gender { get; set; }
    }
    public class EmployeeManager
    {
        private string _cs;
        public EmployeeManager(string con)
        {
            _cs = con;
        }
        public void AddRange(List<Employee> list)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Id");
            dt.Columns.Add("Name");
            dt.Columns.Add("Gender");
            foreach (Employee item in list)
            {
                dt.Rows.Add(item.Id, item.Name, item.Gender);
            }


            using (SqlConnection con = new SqlConnection(_cs))
            {
                //У команді вказуємо назву нашої процедури
                SqlCommand cmd = new SqlCommand("spInsertEmployees", con);
                //Тип команди вклик процедуры
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter paramTVP = new SqlParameter()
                {
                    ParameterName = "@InputEmploees",
                    Value = dt
                };
                cmd.Parameters.Add(paramTVP);

                con.Open();
                cmd.ExecuteNonQuery();
                //con.Close();
            }

        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            List<Employee> list = new List<Employee>();
            EmployeeManager manager = 
                new EmployeeManager("Data Source=.;Initial Catalog=ExampleTableType;Integrated Security=True");

            list.Add(new Employee {
                Id=23,
                Name="Semen",
                Gender="Female"
            });
            list.Add(new Employee
            {
                Id = 44,
                Name = "Vova",
                Gender = "Male"
            });
            manager.AddRange(list);
        }
    }
}
