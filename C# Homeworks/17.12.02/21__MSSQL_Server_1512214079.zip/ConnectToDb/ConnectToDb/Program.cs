﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConnectToDb
{
    class Program
    {
        static void Main(string[] args)
        {
            string role = Console.ReadLine();
            InsertNewRole(role);
            ShowRoles();
        }
        static void ShowRoles()
        {
            string dp = ConfigurationManager.AppSettings["provider"];
            string cnStr = ConfigurationManager.ConnectionStrings["MyConnectionSchool"].ConnectionString;
            DbProviderFactory df = DbProviderFactories.GetFactory(dp);
            using (DbConnection cn = df.CreateConnection())
            {
                cn.ConnectionString = cnStr;
                cn.Open();
                DbCommand cmd = df.CreateCommand();
                cmd.Connection = cn;
                cmd.CommandText = "Select * From Roles";
                using (DbDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        Console.WriteLine("Id: {0} Name: \"{1}\"", dr["Id"], dr["Name"]);
                    }
                }
            }
        }
        static void InsertNewRole(string role)
        {
            string dp = ConfigurationManager.AppSettings["provider"];
            string cnStr = ConfigurationManager.ConnectionStrings["MyConnectionSchool"].ConnectionString;
            DbProviderFactory df = DbProviderFactories.GetFactory(dp);
            using (DbConnection cn = df.CreateConnection())
            {
                cn.ConnectionString = cnStr;
                cn.Open();
                DbCommand cmd = df.CreateCommand();
                cmd.Connection = cn;
                cmd.CommandText = 
                    string.Format("Insert into Roles (Name) Values ('{0}');",role);
                cmd.ExecuteNonQuery();
            }
        }
    }
}
