﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilesWorkDll
{
    public class FileWorker
    {
        public FileWorker()
        {

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputFile"></param>
        /// <param name="strInfo"></param>
        /// <returns></returns>
        public static string FileStreamBinary(string inputFile, string strInfo)
        {
            string result = string.Empty;
            try
            {
                //FileStream fs = File.Open(inputFile, FileMode.Create);
                using (FileStream fs = File.Open(inputFile, FileMode.Create))
                {
                    byte[] byteStr = Encoding.Unicode.GetBytes(strInfo);
                    fs.Write(byteStr, 0, byteStr.Length);
                    fs.Position = 0;
                    byte[] readBytes = new byte[byteStr.Length];
                    for (int i = 0; i < byteStr.Length; i++)
                    {
                        readBytes[i] = Convert.ToByte(fs.ReadByte()); //(byte)fs.ReadByte();
                    }
                    result= Encoding.Unicode.GetString(readBytes);
                }

            }
            catch (Exception ex)
            {
                Debug.WriteLine("Exception FileStreamBinary \"{0}\"", ex.Message);
            }
            return result;

        }

        public static bool CopyFile(string inFileName, string outFileName)
        {
            try
            {
                using (FileStream fsRead = File.OpenRead(inFileName))
                {
                    using (FileStream fsWrite = File.Open(outFileName, FileMode.Create))
                    {
                        var fileSize = fsRead.Length;
                        int i = 0;
                        while(i<fileSize)
                        {
                            byte temp = (byte)fsRead.ReadByte();
                            fsWrite.WriteByte(temp);
                            i++;
                        }
                        return true;
                    }
                }
            }
            catch
            {
                return false;
            }
            return false;
        }
    }
}
