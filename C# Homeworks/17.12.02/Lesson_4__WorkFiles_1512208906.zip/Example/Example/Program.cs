﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FilesWorkDll;

namespace Example
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.InputEncoding = Encoding.Unicode;
            Console.OutputEncoding= Encoding.Unicode;
            DirectoryInfo directory = new DirectoryInfo("images");
            //DirectoryInfo dirFalse = new DirectoryInfo("step");
            //if(!dirFalse.Exists)
            //{
            //    return;
            //}
            var dirDrive = new DirectoryInfo(@"C:\");

            DriveInfo[] drives = DriveInfo.GetDrives();
            foreach(var drive in drives)
            {
                Console.WriteLine("{0} - {1}",  drive.Name, drive.TotalSize);
            }
            
            if(directory.Exists)
            {
                foreach(var file in directory.GetFiles())
                {
                    Console.WriteLine(file.Name);
                }
                foreach (var dir in directory.GetDirectories())
                {
                    //dir.Parent
                } 
            }
            //System.IO.FileInfo fileInfo = new FileInfo(@"hello.ini");
            //FilesWorkDll.FileInfo fileInfo = new FilesWorkDll.FileInfo();
            //FileInfo file("sdfsdf");

            string[] str = {
                "Сніданок",
                "Обід",
                "Вечеря"
            };
            FileInfo fileInfo = new FileInfo("help.txt");
            File.WriteAllLines(fileInfo.FullName, str);
            Console.WriteLine("File all lines");
            foreach(var item in File.ReadAllLines(fileInfo.FullName))
            {
                Console.WriteLine(item);
            }


            string hello = "Hello Peter Іван";

            string work= FileWorker.FileStreamBinary("message.bin", hello);
            Console.WriteLine(work);

            string fileNameCopy = @"c:\Users\Novak\Downloads\1.zip";
            string fileNameOut = "superKovbas.zip";
            var statusCopy=FileWorker.CopyFile(fileNameCopy, fileNameOut);
            if(statusCopy)
            {
                Console.WriteLine("Copy file {0} success!", fileNameOut);
            }
            else
            {
                Console.WriteLine("Error file {0} copy faild!", fileNameOut);
            }

        }
    }
}
