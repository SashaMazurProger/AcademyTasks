namespace ConsoleApp1.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;

    internal sealed class Configuration : DbMigrationsConfiguration<ConsoleApp1.Entities.StepContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(ConsoleApp1.Entities.StepContext context)
        {
            context.Categories.AddOrUpdate(p => p.Id,
                new Entities.Category
                {
                    Id = 1,
                    Name = "��������",
                    ParentId = null
                });
            context.Categories.AddOrUpdate(p => p.Id,
                new Entities.Category
                {
                    Id = 2,
                    Name = "��������",
                    ParentId = null
                });
            context.Categories.AddOrUpdate(p => p.Id,
                new Entities.Category
                {
                    Id = 3,
                    Name = "������",
                    ParentId = 1
                });
            context.Categories.AddOrUpdate(p => p.Id,
                new Entities.Category
                {
                    Id = 4,
                    Name = "��������",
                    ParentId = 1
                });
            context.Categories.AddOrUpdate(p => p.Id,
                new Entities.Category
                {
                    Id = 5,
                    Name = "�����",
                    ParentId = 1
                });
            context.Categories.AddOrUpdate(p => p.Id,
                new Entities.Category
                {
                    Id = 6,
                    Name = "������",
                    ParentId = 2
                });
            context.Categories.AddOrUpdate(p => p.Id,
                new Entities.Category
                {
                    Id = 7,
                    Name = "���������",
                    ParentId = 2
                });
            context.Categories.AddOrUpdate(p => p.Id,
                new Entities.Category
                {
                    Id = 8,
                    Name = "Lenovo",
                    ParentId = 7
                });
            context.Categories.AddOrUpdate(p => p.Id,
                new Entities.Category
                {
                    Id = 9,
                    Name = "Asus",
                    ParentId = 7
                });





            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
            //  to avoid creating duplicate seed data.
        }
    }
}
