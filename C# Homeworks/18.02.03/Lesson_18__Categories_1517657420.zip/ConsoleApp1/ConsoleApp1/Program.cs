﻿using ConsoleApp1.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        #region Igor
        static void RecursionTree(List<Category> tree, int id, string symb)
        {
            symb += "\t";
            for (int k = 0; k < tree.Count; ++k)
            {
                if (tree[k].ParentId == tree[id].Id)
                {
                    Console.Write("\t" + symb);
                    Console.WriteLine(tree[k].Name);
                    RecursionTree(tree, k, symb + "\t");
                }
            }


        }
        static void BuildTree(List<Category> tree)
        {
            for (int i = 0;i<tree.Count; ++i)
            {
                if (tree[i].ParentId == null)
                {
                    Console.WriteLine(tree[i].Name);
                    //recursion run
                    RecursionTree(tree, i, "");
                }
            }
        }
        #endregion

        #region Peter
        static void PrChilds(List<Category> list, int? id, int tabs = 0)
        {
            foreach (var item in list)
            {
                if (item.ParentId == id)
                {
                    Console.Write(new string('\t', tabs));
                    Console.WriteLine(item.Name);
                    PrChilds(list, item.Id, tabs + 1);
                }
            }
        }
        #endregion
        static void Main(string[] args)
        {
            Console.InputEncoding = Encoding.Unicode;
            Console.OutputEncoding = Encoding.Unicode;
            using (StepContext db = new StepContext())
            {
                var list = db.Categories
                    .OrderBy(p=>p.Name)
                    .ToList();
                //Igor
                BuildTree(list);
                //Peter
                //PrChilds(list, null);
                //var query = from c in db.Categories.AsQueryable()
                //            where c.ParentId == null
                //            select c;
                //foreach(var category in query.ToList())
                //{
                //    Console.WriteLine($"{category.Id} {category.Name} {category.ParentId}");
                //    int parentId = category.Id;
                //    int countChildren = 0;
                //    do
                //    {
                //        var list = GetCategory(parentId, db);
                //        countChildren = list.Count;
                //        string margin = "\t";


                //    }
                //    while (countChildren != 0);

                //}

                //foreach (var item in list)
                //{
                //    Console.WriteLine($"Id= {item.Id}\tName: {item.Name}");
                //}
                //List<Category> list = db.Categories.ToList();
                //foreach (var item in list)
                //{
                //    Console.WriteLine($"Id= {item.Id}\tName: {item.Name}");
                //}

            }
        }
    }
}
