namespace ConsoleApp1.Entities
{
    using System;
    using System.Data.Entity;
    using System.Linq;

    public class StepContext : DbContext
    {
       
        public StepContext()
            : base("name=StepConnection")
        {
        }

        public DbSet<Category> Categories { get; set; }
        public DbSet<Product> Products { get; set; }
    }

    //public class MyEntity
    //{
    //    public int Id { get; set; }
    //    public string Name { get; set; }
    //}
}