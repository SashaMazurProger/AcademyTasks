﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example4
{
    class Point
    {
        private int x;
        private int y;
        public Point()
        {
        }
        public Point(int x, int y)
        {
            this.x = x; this.y = y;
        }
        public void Show()
        {
            Console.WriteLine("x = {0}, y = {1}", x, y);
        }
        // оператор true
        public static bool operator true(Point point)
        {
            if (point.x > 0 && point.y > 0)
                return true;
            return false;
        }
        public static bool operator false(Point point)
        {
            if (point.x <= 0 || point.y <= 0)
                return true;
            return false;
        }



    }
    class Program
    {
        static void Main(string[] args)
        {
            Point c = new Point(-3, 1);
            if(c)
            {
                c.Show();
            }
            else
            {
                Console.WriteLine("C false");
            }
        }
    }
}
