﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example5
{
    class User
    {
        private string name;
        public User(string name)
        {
            this.name = name;
        }
        //public static explicit operator string(User user)
        //{
        //    return string.Format("Інформація про користувача: {0}", user.name);
        //}
        public static implicit operator string(User user)
        {
            return string.Format("Інформація про користувача: {0}", user.name);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            User user = new User("Адміністратор");
            //string strUser = (string)user;
            string strUser = user;
            Console.WriteLine(strUser);
            int n=2, m=3;
            int i = 0,j=0;
            double[][] matrix=new double[n][];
            for (i = 0; i < n; i++)
                matrix[i] = new double[m];
            Random r = new Random((int)DateTime.Now.Ticks);
            for(i=0;i<n;i++)
            {
                for(j=0;j<m;j++)
                {
                    matrix[i][j] = r.Next(5, 20);
                }
            }
            Console.WriteLine("Matrix");
            for (i = 0; i < n; i++)
            {
                for (j = 0; j < m; j++)
                {
                    Console.Write("{0} ",matrix[i][j]);
                }
                Console.WriteLine();
            }

        }
    }
}
