﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example2
{
    class Point
    {
        private int x;
        private int y;
        public Point()
        {
        }
        public Point(int x, int y)
        {
            this.x = x; this.y = y;
        }
        public void Show()
        {
            Console.WriteLine("x = {0}, y = {1}", x, y);
        }
        //Перегрузка унарних операторів ++, --, -
        public static Point operator++(Point a)
        {
            a.x++;
            a.y++;
            return a;
        }
        public static Point operator -(Point a)
        {
            a.x=-a.x;
            a.y=-a.y;
            return a;
        }
        public static string operator +(Point a, string str)
        {
            return string.Format("{0}: x = {1}, y = {2}", str, a.x, a.y);
        }


    }
    class Program
    {
        static void Main(string[] args)
        {
            Point p = new Point(34,34);
            p++;
            
            p.Show();
            Point t = -p;
            t.Show();
            Console.WriteLine(t + "Hello t");
        }
    }
}


