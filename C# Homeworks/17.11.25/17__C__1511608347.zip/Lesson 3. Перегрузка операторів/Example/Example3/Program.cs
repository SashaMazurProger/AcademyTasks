﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example3
{
    class Point
    {
        private int x;
        private int y;
        public Point()
        {
        }
        public Point(int x, int y)
        {
            this.x = x; this.y = y;
        }
        public void Show()
        {
            Console.WriteLine("x = {0}, y = {1}", x, y);
        }
        //Логічні оператори
        public static bool operator ==(Point a, Point b)
        {
            if ((a.x == b.x) && (a.y == b.y))
                return true;
            return false;
        }
        public static bool operator !=(Point a, Point b)
        {
            if (a.x != b.x && a.y != b.y)
            {
                return true;
            }
            return false;
        }


    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Point z = new Point(12, 16);
            Point l = new Point(12, 16);
            if (z == l)
                Console.WriteLine("☻^//");
        }
    }
}
