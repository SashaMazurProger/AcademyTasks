﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppOpetatorsObj
{
    class Point
    {
        readonly int _x;
        readonly int _y;
        public Point(int x, int y)
        {
            _x = x;
            _y = y;
        }
        public void Show()
        {
            Console.WriteLine("x={0}, y={1}", _x, _y);
        }
        public static Point operator +(Point a, Point b)
        {
            return new Point(a._x + b._x, a._y + b._y);
        }
        public static bool operator true (Point point)
        {
            if (point._x == 1 && point._y == 1)
                return true;
            else
                return false;
        }
        public static bool operator false(Point point)
        {
            if (point._x == 0 && point._y == 0)
                return true;
            else
                return false;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Point a = new Point(2, 5);
            Point b = new Point(-4, 12);

            Point c = a + b;
            c.Show();
            Point IsTrue = new Point(1, 1);
            if(IsTrue)
            {
                Console.WriteLine("Super bomba");
            }
        }
    }
}
