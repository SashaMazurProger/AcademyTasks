﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example.Classes
{
    internal class User
    {
        private int mId;
        private string mLogin;
        private string mPassword;
        public User()
        {
            mId = 0;
            mLogin = mPassword = null;
        }
        public User(int id, string login, string password)
        {
            mId = id;
            mLogin = login;
            mPassword = password;
        }
        public void Show()
        {
            Console.WriteLine("Ідентифікатор: {0}", mId);
            Console.WriteLine("Логін: {0}", mLogin);
        }
    }
}
