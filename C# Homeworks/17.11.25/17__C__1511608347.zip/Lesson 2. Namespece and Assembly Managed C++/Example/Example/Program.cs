﻿using Example.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CalculatorLibrary;

namespace Example
{
    class Program
    {
        static void Main(string[] args)
        {
            User user = new User(1,"VOVA","123456");
            Console.WriteLine("Інформація про користувача");
            user.Show();
            Console.WriteLine("---------Example Project---------\n");
            Calculator clc = new Calculator();
            Console.WriteLine("Add(23,56) = {0}", clc.Add(23, 56));
        }
    }
}
