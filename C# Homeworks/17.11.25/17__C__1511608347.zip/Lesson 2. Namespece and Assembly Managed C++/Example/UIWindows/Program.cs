﻿using CalculatorLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UIWindows
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("----------Windows UI Project---------\n");
            Calculator clr = new Calculator();
            Console.WriteLine("Add(23,56)={0}", clr.Add(23, 56));
        }
    }
}
