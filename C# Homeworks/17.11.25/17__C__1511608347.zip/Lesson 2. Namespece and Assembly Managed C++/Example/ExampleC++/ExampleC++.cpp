// ExampleC++.cpp : main project file.

#include "stdafx.h"

using namespace System;
using namespace CalculatorLibrary;

int main(array<System::String ^> ^args)
{
    Console::WriteLine(L"Hello World");
	Console::WriteLine(L"----------Example C++ Project---------\n");
	Calculator clr;
	Console::WriteLine("Add(23,56)={0}", clr.Add(23, 56));
    return 0;
}
