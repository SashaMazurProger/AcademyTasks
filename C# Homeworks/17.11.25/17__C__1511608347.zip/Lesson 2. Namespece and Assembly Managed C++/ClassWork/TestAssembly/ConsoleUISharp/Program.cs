﻿using BlaBla;
using MyDll;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUISharp
{
    class Oksana
    {
        static void Main(string[] args)
        {
            //Caculator calc = new Caculator();
            //int sum = calc.Add(4, 5);
            //Debug.WriteLine("Hello sum={0}", sum);
            //Console.WriteLine("5+4={0}",sum);
            //Victor victor = new Victor();
            //victor.Show();

            User user = new User
            {
                Name="Іван Петрович",
                Age=23,
                DateBirth=Convert.ToDateTime("23.12.00")
            };
            User peter = new User("Tom Duglas", 45, DateTime.Now);

            string userInfoPeter = peter.ToString();
            Console.WriteLine(userInfoPeter);

        }
    }
}
