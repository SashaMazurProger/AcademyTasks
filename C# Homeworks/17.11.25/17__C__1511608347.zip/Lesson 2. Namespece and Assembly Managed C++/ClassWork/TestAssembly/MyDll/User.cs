﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyDll
{
    /// <summary>
    /// Цей клас для збереження користувачів в системі
    /// </summary>
    public class User
    {
        private string _name;
        private int _age;
        public DateTime DateBirth { get; set; }

        public int Age
        {
            get { return _age; }
            set {
                if(value>=5 && value<=89)
                    _age = value;
            }
        }

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        
        public User()
        {

        }
        /// <summary>
        /// Ініціалізація обєкта класа корисувач
        /// </summary>
        /// <param name="name">Імя кристувача</param>
        /// <param name="age">Вік</param>
        /// <param name="dateBirth">Дата народження</param>
        public User(string name, int age, DateTime dateBirth)
        {
            this.Name = name;
            this.DateBirth = dateBirth;
            this.Age = age;
        }
        public override string ToString()
        {
            var userInfo = $"Name: {this.Name}\tAge: {this.Age}\t " +
                $"DateBirth:{this.DateBirth.ToLongDateString()}";
            return userInfo;
        }
    }
    public class Mark
    {
        public int Bal { get; set; }
        public string Discipline { get; set; }
    }
    public class Student : User {
        private Mark[] _marks;
        public Student()
        {
            _marks = new Mark[200];
        }
    }

}
