﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyDll
{
    public class Caculator
    {
        private static int _count;
        private string _name;
        

        public Caculator()
        {
            _name = null;
            Console.WriteLine(_name);
        }
        
        public int Add(int a, int b)
        {
            _count = a + b;
            return _count;
        }
    }
}
