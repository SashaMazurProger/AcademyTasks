﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtentionMethod
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 20;
            Console.WriteLine(a.MyToString());

            int[] p = { 23, 34, 32, 32, -7, 2, -4, 12, 0, 34 };
            var listMinus = p.Where(x => x < 0).Count();
            Console.WriteLine(listMinus);
            var listMinSQL =
                        (from data in p
                        where data < 0
                        select data).Count();
            
        }
    }
    static class IntExtention
    {
        public static string MyToString(this int obj)
        {
            return string.Format("Це моя перегрузка: {0}",
                obj);
        }
    }
}
