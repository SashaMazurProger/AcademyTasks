﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example
{
    struct hello
    {
        private int age;
        public string Convert()
        {
            return "Hello";
        }
    }
    class CHello
    {
        int age;
        public CHello()
        {

        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введіть дану народження:");
            string p = Console.ReadLine();
            
            int age = 0;
            try
            {
                DateTime date = Convert.ToDateTime(p);
                DateTime now = DateTime.Now;
                TimeSpan time = new TimeSpan((now - date).Ticks);
                age = time.Days/365;
            }
            catch (Exception ex)
            {
                string strError=string.Format("--------Виникла помилка '{0}'--------", ex.Message);
                Console.WriteLine(strError);
            }
            finally
            {
                Random r = new Random();
                if (age == 0)
                    age = r.Next(12, 80);
            }
            Console.WriteLine($"Вам зараз {age}");
        }
    }
}
