USE [29_Vova]
GO
SELECT u.Name as UserName, r.Name as RoleName 
FROM Users as u, UserRoles as ur, Roles as r
WHERE u.Id=ur.UserId AND ur.RoleId=r.Id