﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpHomeWork._17._11._11
{
    //class Program     //ЩАСЛИВИЙ НОМЕР ТРАМВАЯ
    //{
    //    static void Main(string[] args)
    //    {
    //        int firstSum=0, lastSum=0;
    //        ConsoleKeyInfo key;

    //        do
    //        {
    //            Console.Write("Number(6 digits): ");
    //            for (int i = 0; i < 6; ++i)
    //            {
    //                key = Console.ReadKey();
    //                char symbol = key.KeyChar;
    //                if (char.IsDigit(symbol))
    //                {
    //                    int digit = int.Parse(char.ToString(symbol));
    //                    if (i < 3)
    //                    {
    //                        firstSum += digit;
    //                    }
    //                    else
    //                    {
    //                        lastSum += digit;
    //                    }
    //                }
    //            }
    //            if (firstSum == lastSum)
    //            {
    //                Console.WriteLine("\nThe number is happy!!!");
    //            }
    //            else
    //            {
    //                Console.WriteLine("\nThe number isn't happy(");
    //            }
    //        } while (true);
    //    }
    //}
}
