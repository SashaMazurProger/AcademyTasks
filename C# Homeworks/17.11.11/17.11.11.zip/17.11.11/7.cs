﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpHomeWork._17._11._11
{
    class Program      //СОРТУВАННЯ МАСИВУ ВІД -ЗНАЧЕНЬ ДО +, ЗІ ЗБЕРЕЖЕННЯМ ПОЗИЦІЇ
    {
        static void Main(string[] args)
        {
            Random random = new Random();
            int[] numbers = new int[random.Next(5,15)];

            for (int i = 0; i < numbers.Length; ++i)
            {
                numbers[i] = random.Next(-5, 10);
            }
            numbers.Print();
            numbers.SortArrayWithDivision();
            Console.WriteLine("\n\n***Sort array from least to biggest number with keep number's position***");
            numbers.Print();
            Console.Write("\n\nTry again?(y-YES,n-NO):");
            if (Console.ReadKey().KeyChar != 'n' && Console.ReadKey().KeyChar != 'N')
            {
                Console.Clear();
                Program.Main(null);
            }
            else
            {
                Environment.Exit(0);
            }
        }
    }
    public static class ArrayMethods
    {
        public static void Print<T>(this T [] arr)
        {
            try
            {
                Console.Write("Items of array:");
                foreach (var item in arr)
                {
                    Console.Write("[{0}]", item);
                }
            }
            catch (Exception e)
            {

                Console.WriteLine("\n"+e.Message);
            }
        }
        public static void SortArrayWithDivision(this int [] arr)
        {
            int[] minusNumbers = new int[0],
                plusNumbers = new int[0];

            for (int i = 0; i < arr.Length; ++i)
            {
                if (arr[i] < 0)
                {
                    Array.Resize(ref minusNumbers, minusNumbers.Length + 1);
                    minusNumbers.SetValue(arr[i], minusNumbers.Length - 1);
                }
                else
                {
                    Array.Resize(ref plusNumbers, plusNumbers.Length + 1);
                    plusNumbers.SetValue(arr[i], plusNumbers.Length - 1);
                }
            }
            Array.Copy(minusNumbers, arr, minusNumbers.Length);
            Array.ConstrainedCopy(plusNumbers, 0, arr, minusNumbers.Length, plusNumbers.Length);
        }
    }
}
