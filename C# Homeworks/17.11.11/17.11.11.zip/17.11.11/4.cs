﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpHomeWork._17._11._11
{
    class Program      //РЕВЕРС ЧИСЛА
    {
        static void Main(string[] args)
        {
            string str = "";

            ConsoleKeyInfo key;
            Console.Write("Input: ");
            do
            {
                key = Console.ReadKey();
                char keyChar = key.KeyChar;
                if (char.IsDigit(keyChar))
                {
                    str = str.Insert(0, keyChar.ToString());
                }
            } while (key.Key != ConsoleKey.Enter);
            Console.WriteLine("\nReverse number:" + int.Parse(str));
            Console.ReadKey();
        }
    }
}
