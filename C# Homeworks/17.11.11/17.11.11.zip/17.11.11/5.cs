﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpHomeWork._17._11._11
{
    class Program      //СТРОКА-ОПИС ЧИСЛА
    {
        static Dictionary<int,string> hundreds=new Dictionary<int, string>
        {
            { 1,"сто"},
            { 2,"двісті"},
            { 3,"триста"},
            { 4,"чотириста"},
            { 5,"пятсот"},
            { 6,"шістсот"},
            { 7,"сімсот"},
            { 8,"вісімсот"},
            { 9,"девятсот"}
        };
        static Dictionary<int, string> dozens = new Dictionary<int, string>
        {
            { 1,"десять"},
            { 2,"двадцять"},
            { 3,"тридцять"},
            { 4,"сорок"},
            { 5,"пятдесят"},
            { 6,"шістдесят"},
            { 7,"сімдесят"},
            { 8,"вісімдесят"},
            { 9,"девяносто"}
        };
        static Dictionary<int, string> units = new Dictionary<int, string>
        {
            { 0,""},
            { 1,"один"},
            { 2,"два"},
            { 3,"три"},
            { 4,"чотири"},
            { 5,"пять"},
            { 6,"шість"},
            { 7,"сім"},
            { 8,"вісім"},
            { 9,"девять"}
        };
        static Dictionary<int, string> numbersFromTenToTwenty = new Dictionary<int, string>
        {
            { 1,"одинадцять"},
            { 2,"дванадцять"},
            { 3,"тринадцять"},
            { 4,"чотирнадцять"},
            { 5,"пятнадцять"},
            { 6,"шістнадцять"},
            { 7,"сімнадцять"},
            { 8,"вісімнадцять"},
            { 9,"девятнадцять"}
        };

        static void Main(string[] args)
        {
            string numberString;

            Console.WriteLine();
            ConsoleKeyInfo key;
            do
            {
                numberString = "";
                Console.Write("\nInput number(100-999): ");
                do
                {
                    key = Console.ReadKey();
                    char keyChar = key.KeyChar;
                    if (char.IsDigit(keyChar))
                    {
                        numberString += keyChar.ToString();
                    }
                } while (numberString.Length != 3);
                Console.WriteLine("\nWords value of the number:{0}", CreateWords(numberString));
            } while (true);
        }
        static string CreateWords(string number)
        {
            string result = "";

            int hundred = int.Parse(number[0].ToString());
            if (hundred != 0)
            {
                result += hundreds[hundred];
            }

            int endDigit = int.Parse(number[2].ToString());
            int dozen = int.Parse(number[1].ToString());
            switch (dozen)
            {
                case 0:
                    result += (" " + units[endDigit]);
                    break;

                case 1:
                    if (endDigit == 0)
                    {
                        result += (" " + dozens[1]);
                    }
                    else
                    {
                        result += (" " + numbersFromTenToTwenty[endDigit]);
                    }
                    break;

                default:
                    result += (" " + dozens[dozen]);
                    result += (" " + units[endDigit]);
                    break;
            }
            return result;
        }
    }
}
