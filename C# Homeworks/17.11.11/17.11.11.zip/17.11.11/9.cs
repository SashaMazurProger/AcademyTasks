﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpHomeWork._17._11._11
{
    class Program      //МАСИВ ТОВАРІВ ТА ЦІН
    {
        private static Random random = new Random();
        static void Main(string[] args)
        {
            string[] phones = new string[10]
                {
                   "Xiaomi mi6",
                   "Google Nexus 5",
                   "Google Nexus 6P",
                   "Samsung Galaxy S8",
                   "Samsung Galaxy S7",
                   "Iphone X",
                   "LG G6",
                   "Iphone 8",
                   "Xiaomi RNote 3 Pro",
                   "Sony Xperia Z3+"
                };
                decimal[] prices = new decimal[10]
                {
                    8000,
                    4500,
                    9000,
                    25000,
                    20000,
                    35000,
                    18000,
                    28000,
                    5900,
                    10000,
                };

            Console.WriteLine("\n//Sort phones by descending".ToUpper());
            Program.SortArrays(ref phones, ref prices, true);
            Print(phones, prices);

            Console.WriteLine("\n\n//Sort phones by ascending".ToUpper());
            Program.SortArrays(ref phones, ref prices);
            Print(phones, prices);

            //зберігаємо результат сортув. для подальшого використання
            string[] sortNamesAsc = new string[phones.Length];
            decimal[] sortPricesAsc = new decimal[prices.Length];
            phones.CopyTo(sortNamesAsc, 0);
            prices.CopyTo(sortPricesAsc, 0);

            //виводимо найдешевші/найдорожчі товари
            do
            {
                Console.Write("\n\nChoose category of products(A-most expensive,D-cheapest,0-Exit):".ToUpper());
                char key = Console.ReadKey().KeyChar;

                if (key == '0')
                {
                    return;
                }

                int count;
                do
                {
                    Console.Write("\nPlease, input how many products do you want to see(max:{0}): ".ToUpper(),
                        phones.Length);

                    int.TryParse(Console.ReadLine(), out count);
                } while (count <= 0||count>phones.Length);

                switch (key)
                {
                   //показуємо найдорожчі товари
                   case 'A':
                   case 'a':
                        Program.Print(sortNamesAsc,sortPricesAsc, count,true);
                        break;
                   //показуємо найдешевші товари
                   case 'D':
                   case 'd':
                        Program.Print(sortNamesAsc, sortPricesAsc, count,false);
                        break;
                }
            } while (true);
        }
        static void SortArrays(ref string[] names, ref decimal[] prices,
                                bool descending = false)
        {
            decimal[] tmpPrices = new decimal[prices.Length];
            string[] tmpNames = new string[names.Length];
            Array.Copy(prices, tmpPrices, prices.Length);
            if (descending)
            {
                //сортуємо основний масив цін за спаданням
                Array.Sort(prices, (a, b) => -a.CompareTo(b));
            }
            else
            {
                //сортуємо основний масив цін за зрост.
                Array.Sort(prices, (a, b) => a.CompareTo(b));
            }
                //сортуємо масив назв 
            for (int i = 0; i < prices.Length; ++i)
            {
                int index = Array.IndexOf(tmpPrices, prices[i]);
                tmpNames[i] = names[index];
            }
            //масив відсортованих назв призначаємо нашому основному масиву назв
            names = tmpNames;
        }
        public static void Print(string[]names,decimal []prices)
        {
            try
            {
                Console.Write("\n{0,20}{1,8}","NAME","PRICE");
                for (int i = 0; i < names.Length; ++i)
                {
                    Console.Write("\n{0,20}{1,8}",names[i],prices[i]);
                }
            }
            catch (Exception e)
            {

                Console.WriteLine("\n" + e.Message);
            }
        }
        //вивід найдешевших/найдорожчих товарів
        public static void Print(string[] names, decimal[] prices, int countElements, bool takeMostExpensive)
        {
            try
            {
                int beginIndex = takeMostExpensive ? (names.Length) - countElements : 0;
                Console.Write("\n{0,20}{1,8}", "NAME", "PRICE");
                for (int i = beginIndex,counter=0; counter < countElements; ++i,++counter)
                {
                    Console.Write("\n{0,20}{1,8}", names[i], prices[i]);
                }
            }
            catch (Exception e)
            {

                Console.WriteLine("\n" + e.Message);
            }
        }
    }
}
