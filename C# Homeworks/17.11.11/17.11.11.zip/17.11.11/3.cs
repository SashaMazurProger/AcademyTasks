﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpHomeWork._17._11._11
{
    class Program       //КОНВЕРТЕР РЕГІСТРУ РЯДКІВ 
    {
        static void Main(string[] args)
        {
            ConsoleKeyInfo keyInfo;
            string str = "";

            Console.Write("Input:");

            do
            {
                keyInfo = Console.ReadKey();
                char symb = keyInfo.KeyChar;
                if (char.IsLetterOrDigit(symb)&&!char.IsDigit(symb))
                {

                    if (char.IsUpper(symb))
                    {
                        str+=((char) ((int)keyInfo.Key + 32));
                    }
                    else
                    {
                        str += ((char)keyInfo.Key);
                    }
                }
            } while (keyInfo.Key != ConsoleKey.Enter);
            Console.Write("\nResult string:" + str);
            Console.ReadKey();
        }

    }

}
