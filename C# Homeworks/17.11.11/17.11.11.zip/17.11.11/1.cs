﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpHomeWork._17._11._11
{
    class Program      //КІЛЬКІСТЬ ПРОПУСКІВ
    {
        static void Main(string[] args)
        {
            int spaceKeys = 0;
            ConsoleKeyInfo key;
            Console.Write("Input: ");
            do
            {
                key = Console.ReadKey();
                if (key.Key == ConsoleKey.Spacebar)
                    ++spaceKeys;
            } while (key.Key != ConsoleKey.OemPeriod);
            Console.WriteLine("\nSpace keys:" + spaceKeys);
            Console.ReadKey();
        }
    }
}
