﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpHomeWork._17._11._11
{
    class Program      //МЕТОДИ ОБРОБКИ МАСИВУ
    {
        private static Random random = new Random();
        static void Main(string[] args)
        {
            Console.WriteLine("\n//Create random number's array");
            int[] arr = Program.CreateRandomArray(10);
            arr.Print();

            Console.WriteLine("\n\n//Print the array");
            arr.Print();

            Console.WriteLine("\n\n//Remove all zeroes from the array");
            Program.RemoveZeroes(ref arr);
            arr.Print();

            Console.WriteLine("\n\n//Add element to array");
            //arr.AddElementToArray(12);
            Program.AddElementToArray(ref arr, 12);
            arr.Print();

            Console.Write("\n\nTry again?(y-YES,n-NO):");
            if (Console.ReadKey().KeyChar != 'n' && Console.ReadKey().KeyChar != 'N')
            {
                Console.Clear();
                Program.Main(null);
            }
            else
            {
                Environment.Exit(0);
            }
        }
        static int[] CreateRandomArray(int size)
        {
            int[] numbers = new int[size];
            for (int i = 0; i < numbers.Length; ++i)
            {
                numbers[i] = random.Next(-5,5);
            }
            return numbers;
        }
        static void RemoveZeroes(ref int[] arr)
        {
            int[] numbers = Array.FindAll(arr, a => a != 0);
            Array.Resize(ref arr, numbers.Length);
            Array.Copy(numbers, arr, numbers.Length);

            //int[] numbers = new int[0];

            //for (int i = 0; i < arr.Length; ++i)
            //{
            //    if (arr[i] != 0)
            //    {
            //        Array.Resize(ref numbers, numbers.Length + 1);
            //        numbers.SetValue(arr[i], numbers.Length - 1);
            //    }
            //}
            //Array.Resize(ref arr, numbers.Length);
            //Array.Copy(numbers, arr, numbers.Length);
        }
        static void AddElementToArray(ref int[] arr, int element)
        {
            Array.Resize(ref arr, arr.Length + 1);
            arr.SetValue(element, arr.Length - 1);
        }
    }
    
    public static class ArrayMethods
    {
        public static void Print<T>(this T[] arr)
        {
            try
            {
                Console.Write("Items of array:");
  
                foreach (var item in arr)
                {
                    Console.Write("[{0,7}]", item);
                }
            }
            catch (Exception e)
            {

                Console.WriteLine("\n" + e.Message);
            }
        }
        public static void AddElementToArray<T>( this T [] arr,T element)
        {
            Array.Resize(ref arr, arr.Length + 1);
            arr.SetValue(element, arr.Length - 1);
        }
    }
}
