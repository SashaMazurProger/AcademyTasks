﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpHomeWork._17._11._11
{
    class Program      //СУМА ЧИСЕЛ МАСИВУ В ДІАПАЗОНІ ВІД НАЙМЕНШОГО ДО НАЙБІЛЬШОГО ЧИСЛА
    {
        static void Main(string[] args)
        {
            int maxIndex,minIndex;
            Random random = new Random();
            int[] numbers = new int[10];

            Console.Write("\nNumber's array:");
            for (int i = 0; i < numbers.Length; ++i)
            {
                numbers[i] = random.Next(-5, 10);
                Console.Write("[{0}]",numbers[i]);
            }
            SearchIndexes(numbers,out minIndex, out maxIndex);
            Console.WriteLine("\nSum from {0}(min) to {1}(max) is {2}",
                numbers[minIndex],
                numbers[maxIndex],
                SumNumbers(numbers,minIndex,maxIndex));
            Console.Write("\nTry again?(y-YES,n-NO):");
            if (Console.ReadKey().KeyChar != 'n'&& Console.ReadKey().KeyChar != 'N')
            {
                Console.Clear();
                Program.Main(null);
            }
            else
            {
                Environment.Exit(0);
            }
        }

        static int SumNumbers(int[] numbers, int minIndex, int maxIndex)
        {
            int sum = 0;
            for (int i = minIndex<=maxIndex?minIndex+1:maxIndex+1,
                max = minIndex <= maxIndex ? maxIndex : minIndex;
                i < max; ++i)
            {
                sum += numbers[i];
            }
            return sum;
        }

        static void SearchIndexes(int[] arr, out int minIndex, out int maxIndex)
        {
            int maxValue=arr[0], minValue=arr[0];
            minIndex = 0;
            maxIndex = 0;
            for (int i = 0; i < arr.Length; ++i)
            {
                if (maxValue < arr[i])
                {
                    maxValue = arr[i];
                    maxIndex = i;
                }
                if (minValue > arr[i])
                {
                    minValue = arr[i];
                    minIndex = i;
                }
            }
        }
    }
}
